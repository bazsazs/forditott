const inputElem = document.getElementById('inputText');
        const resultElem = document.getElementById('result');

        // Arrow function a szöveg megfordítására
        const megfordit = () => {
            const szoveg = inputElem.value;
            const megforditottSzoveg = szoveg.split('').reverse().join('');
            resultElem.textContent = `Eredeti szöveg: ${szoveg}, Megfordított szöveg: ${megforditottSzoveg}`;
        };